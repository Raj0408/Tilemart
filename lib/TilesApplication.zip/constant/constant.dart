
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

final  textstyle =  TextStyle(
    color: Colors.black,
    fontSize: 22,
    fontWeight: FontWeight.w400,
    fontFamily: 'Montserrat',
);