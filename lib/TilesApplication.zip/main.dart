import 'dart:ui';


import 'package:flutter/material.dart';
import 'package:tilesapplication/model/tiles.dart';
import 'appbar/appbar.dart';
import 'slider/columnview.dart';
import 'Pages/product.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,


      routes: {
        '/' : (context) => CustomBarWidget(),
        product.id : (context) => product(tileslist: [], index: 0,),

      }
    );
  }
}
