import 'package:flutter/material.dart';
import 'package:tilesapplication/appbar/appbar.dart';
import 'package:tilesapplication/model/tiles.dart';

class product extends StatelessWidget {

  static String id = 'product_page';
 final List<tiles> tileslist;
  final int index ;
product({required this.tileslist,required this.index});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          children: [
            Image(image: AssetImage(tileslist[index].path)),
            Text(tileslist[index].name),
          ],
           // Text(tileslist[index].name),
        ),
      ),


    );
  }
}
