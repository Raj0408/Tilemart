import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:tilesapplication/model/tiles.dart';
import 'package:tilesapplication/constant/constant.dart';


class CarouselWidgete extends StatelessWidget {
  const CarouselWidgete({
    Key? key,
    required this.product,
    required this.viewportFraction
  }) : super(key: key);

  final List<tiles> product;
  final double viewportFraction ;

  @override
  Widget build(BuildContext context) {
    return CarouselSlider(
      options: CarouselOptions(
        enlargeCenterPage: true,
        enableInfiniteScroll: false,
        autoPlay: true,
        viewportFraction: 0.97

      ),
      items: product
          .map((e) => ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          fit: StackFit.expand,
          children: <Widget>[
            Image(
              image: AssetImage(e.path),
              width: 1030,
              height: 350,
              fit: BoxFit.cover,
            ),
            Container(
              margin: EdgeInsets.only(top: 140,left: 18),
              child: Text(e.name,style: textstyle),
            )
          ],
        ),
      ))
          .toList(),
    );
  }
}
