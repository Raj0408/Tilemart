class tiles {
  final String name ;
  final String path;

  tiles({required this.name,required this.path});
}