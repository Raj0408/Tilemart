import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tilesapplication/model/tiles.dart';

import 'package:tilesapplication/slider/columnview.dart';
import  'package:tilesapplication/Pages/product.dart';
import 'package:google_nav_bar/google_nav_bar.dart';

import '../Pages/home.dart';

class CustomBarWidget extends StatefulWidget {

  @override
  State<CustomBarWidget> createState() => _CustomBarWidgetState();
}

class _CustomBarWidgetState extends State<CustomBarWidget> {


  GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();

  int selectedindex = 0;
  final List<Widget> _children = [
     homepage(),
    product(tileslist: [],index: 0,),
  ];

  int _selectedIndex = 0;
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      body: _children[_selectedIndex],
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          borderRadius: BorderRadius.only(
              topRight: Radius.circular(20), topLeft: Radius.circular(20)),
          boxShadow: [
            BoxShadow(color: Colors.black38, spreadRadius: 0, blurRadius: 10),
          ],
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(30.0),
            topRight: Radius.circular(30.0),
          ),
          child: BottomNavigationBar(
            backgroundColor: Colors.orange,
            items: const <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                icon: Icon(Icons.home),
                label: 'Home',
                backgroundColor: Colors.orange,
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.shopping_basket),
                label: 'Products',
                backgroundColor: Colors.orange,
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.person_outline),
                label: 'About Us',
                backgroundColor: Colors.orange,
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.call),
                label: 'Contact us',
                backgroundColor: Colors.orange,
              ),
            ],
            currentIndex: _selectedIndex,
            selectedItemColor: Colors.white,
            onTap: _onItemTapped,
            type: BottomNavigationBarType.shifting,
            iconSize: 25,
          ),
        ),
      ),
    );
  }
}
//
// BottomAppBar(
//
// shape: CircularNotchedRectangle(),
// notchMargin: 6.0,
// color: Colors.transparent,
// elevation: 9.0,
// clipBehavior: Clip.antiAlias,
// child: Container(
// height: 55.0,
// decoration: BoxDecoration(
// borderRadius: BorderRadius.only(
// topLeft: Radius.circular(80.0),
// topRight: Radius.circular(80.0),
// bottomRight: Radius.circular(80.0),
// bottomLeft: Radius.circular(80.0),
// ),
// color: Colors.orange
// ),
// child: Row(
// mainAxisAlignment: MainAxisAlignment.spaceBetween,
// children: [
// Container(
// height: 50.0,
// width: MediaQuery.of(context).size.width ,
// child: Padding(
// padding: const EdgeInsets.only(left: 23),
// child: Row(
//
// crossAxisAlignment: CrossAxisAlignment.center,
// mainAxisAlignment: MainAxisAlignment.spaceAround,
// children: <Widget>[
// Icon(Icons.home, color: _selecthome ? Color(0xFFEF7532) : Color(0xFF676E79),size: 30,),
//
//
// FlatButton(
// onPressed: (){
// _selectproduct = true;
// _selectabout = false;
// _selecthome = false;
// _selectcontact = false;
// Navigator.pushNamed(context, product.id);
// },
// child: Icon(Icons.shopping_basket, color: _selectproduct ? Color(0xFFEF7532)  :Color(0xFF676E79) ,size: 30,)),
// Icon(Icons.call, color: Color(0xFF676E79),size: 30,),
// Icon(Icons.person_outline, color: Color(0xFF676E79),size: 30,),
//
//
// ],
// ),
// )
// ),
//
// ]
// )
// )
// ),

