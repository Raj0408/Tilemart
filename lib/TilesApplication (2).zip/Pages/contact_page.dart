import 'package:flutter/material.dart';

class contact_page extends StatelessWidget {
  const contact_page({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        child: Text("This is contact Page"),
      ),
    );
  }
}
