import 'package:flutter/material.dart';
import 'package:tilesapplication/slider/columnview.dart';
import 'package:tilesapplication/model/tiles.dart';
import 'package:tilesapplication/model/title_detail.dart';


class homepage extends StatefulWidget {
  const homepage({Key? key}) : super(key: key);

  @override
  State<homepage> createState() => _homepageState();
}

class _homepageState extends State<homepage> {

  GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      key: _scaffoldKey,
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: 160.0,
              child: Stack(
                children: <Widget>[
                  Container(

                    decoration: BoxDecoration( borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(30),
                      bottomLeft: Radius.circular(30),

                    ),
                      color: Colors.orange,),
                    width: MediaQuery.of(context).size.width,
                    height: 130.0,

                    child: Center(
                      child: Text(
                        "Tiles Application",
                        style: TextStyle(color: Colors.white, fontSize: 20.0,fontFamily: 'Montserrat'),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 110.0,
                    left: 0.0,
                    right: 0.0,
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 20.0),
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5.0),
                            border: Border.all(
                                color: Colors.grey.withOpacity(0.5), width: 1.0),
                            color: Colors.white),
                        child: Row(
                          children: [
                            IconButton(
                              icon: Icon(
                                Icons.search,
                                color: Colors.orangeAccent,
                              ),
                              onPressed: () {
                                print("your menu action here");
                              },
                            ),
                            Expanded(
                              child: TextField(
                                onTap: (){
                                  Navigator.pushNamed(context, 'SearchPage');
                                },
                                decoration: InputDecoration(

                                  floatingLabelAlignment: FloatingLabelAlignment.center,
                                  border: InputBorder.none,
                                  hintText: "Search",
                                  alignLabelWithHint: true
                                ),
                              ),
                            ),


                          ],
                        ),

                      ),
                    ),
                  ),

                ],
              ),
            ),


            ColumnWidget(recent_product: recent_product, Trending_Product: Trending_Product, Recently_Added: Recently_Added),

          ],
        ),
      ),
    );
  }
}
