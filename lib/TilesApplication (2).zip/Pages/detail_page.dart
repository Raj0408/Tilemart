import 'package:flutter/material.dart';
import 'package:tilesapplication/appbar/appbar.dart';
import 'package:tilesapplication/model/tiles.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:tilesapplication/constant/constant.dart';
import 'camera_page.dart';
import 'package:camera/camera.dart';

class detail_page extends StatelessWidget {

  static String id = 'product_page';
  List<tiles_type> tileslist;
  final int index ;
  detail_page({required this.tileslist,required this.index});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: const BackButton(color: Colors.black),
        actions: [
          IconButton(
              onPressed: () {},
              icon: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: SvgPicture.asset(
                    "assets/icons/heart.svg",
                    height: 20,
                  )))
        ],
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.only(top: 23,left: 14,right: 14),
          child: ClipRRect(

            borderRadius: BorderRadius.all(Radius.circular(15)),
            child: Image.asset(
              tileslist[index].path,
              height: MediaQuery.of(context).size.height * 0.4,
              fit: BoxFit.cover,
            ),
          ),
        ),
        const SizedBox(
          height: defaultPadding,
        ),
        Expanded(
            child: Container(
              padding: const EdgeInsets.fromLTRB(defaultPadding, defaultPadding * 2,
                  defaultPadding, defaultPadding),
              decoration: const BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(defaultBorderRadius * 3),
                    topRight: Radius.circular(defaultBorderRadius * 3)),
              ),
              child: SingleChildScrollView(
                child: Column(children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(tileslist[index].name,
                            style: Theme.of(context).textTheme.headline6),
                      ),
                      const SizedBox(
                        width: defaultPadding,
                      ),
                      Text(
                        "₹" +"${tileslist[index].prize}",
                        style: Theme.of(context).textTheme.headline6,
                      ),
                    ],
                  ),
                  const Padding(
                    padding: const EdgeInsets.symmetric(vertical: defaultPadding),
                    child: const Text(
                        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy"),
                  ),
                  const SizedBox(
                    height: defaultPadding * 1.5,
                  ),
                  Center(
                    child: SizedBox(
                      width: 200,
                      height: 48,
                      child: ElevatedButton(
                          onPressed: () async {
                            await availableCameras().then(
                                  (value) =>
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) =>
                                          CameraPage(
                                            camera: value[0],
                                            tilesdata: tileslist[index],
                                          ),
                                    ),
                                  ),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                              primary: Colors.orange, shape: const StadiumBorder()),
                          child: const Text(
                            "use camera",
                          )),
                    ),
                  ),
                ]),
              ),
            ))
      ]),
    );
  }
}
