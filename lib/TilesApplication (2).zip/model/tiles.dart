
class tiles_type {
  final String name ;
  final String path;
  final int prize;

  tiles_type({required this.name,required this.path,required this.prize});
}